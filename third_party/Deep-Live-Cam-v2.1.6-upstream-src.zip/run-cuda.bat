@echo off
chcp 65001 >nul
title Deep-Live-Cam (CUDA)
cd /d "%~dp0"

echo ==========================================
echo  Deep-Live-Cam 正在启动（CUDA 加速）
echo  首次启动加载模型，需要等 20-40 秒
echo  窗口出现前不要关闭本窗口
echo ==========================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0.venv\Scripts\python.exe' '%~dp0run.py' --execution-provider cuda 2>&1 | Tee-Object -FilePath '%~dp0runtime.log'"

echo.
echo ==========================================
echo  程序已退出
echo  运行日志: %~dp0runtime.log
echo  如果窗口没出现，请把 runtime.log 发给开发者
echo ==========================================
pause
