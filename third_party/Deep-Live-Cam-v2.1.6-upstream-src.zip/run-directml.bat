@echo off
chcp 65001 >nul
title Deep-Live-Cam (DirectML)
cd /d "%~dp0"

echo ==========================================
echo  Deep-Live-Cam 正在启动（DirectML 加速）
echo  注意：DirectML 需要额外安装 onnxruntime-directml
echo  如果你的显卡是 NVIDIA，建议改用 run-cuda.bat
echo ==========================================
echo.

"%~dp0.venv\Scripts\python.exe" "%~dp0run.py" --execution-provider dml

echo.
echo ==========================================
echo  程序已退出（如有报错请截图发给开发者）
echo ==========================================
pause
